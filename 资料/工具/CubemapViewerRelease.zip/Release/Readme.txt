Oculus Cubemap Viewer v1

---------------------------------------------------------------------------------
To run on Windows with an Oculus Rift:

Place an 12288 x 2048 png file in this folder, and rename it to cubemap.png

Run CubemapViewer.exe

Use the mouse to look around, and Escape to quit.

---------------------------------------------------------------------------------
To run on Gear VR:

Copy your 12288 x 2048 png to /sdcard/ rename it to cubemap.png:

adb push your_cubemap.png /sdcard/cubemap.png

Install the CubemapViewer application and run it from your phone launcher:

adb install -r path/to/CubemapViewer.apk

---------------------------------------------------------------------------------

Check that your cubemap looks correct:
  -make sure the forward direction is where you expect it to be
  -check for visible seams between the cube sides

---------------------------------------------------------------------------------
